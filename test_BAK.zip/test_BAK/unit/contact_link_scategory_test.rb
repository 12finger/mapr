require 'test_helper'

class ContactLinkScategoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
