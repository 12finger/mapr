require 'test_helper'

class Link1sHelperTest < ActionView::TestCase
end
