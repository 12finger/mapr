require 'test_helper'

class ContactLinkScategoriesHelperTest < ActionView::TestCase
end
