require 'test_helper'

class Link1Test < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
